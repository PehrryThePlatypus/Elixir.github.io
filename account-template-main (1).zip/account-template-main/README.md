# Sellix.io / Shoppy.gg Template
- [Sellix.io / Shoppy.gg Template](#sellixio--shoppygg-template)
<div style="text-align: center;">

**Change your Product ID and the Logo**

*Sellix.io Guide*

*Dashboard -> Developers -> Embed Products -> Generate Code -> Your Product -> copy data-sellix-product="YOURID"*

*Shoppy.gg Guide*

*Dashboard -> Products -> All Products -> Copy Code under Product name



Preview: 
</div>

![](https://i.imgur.com/vTT5hU0.png)
